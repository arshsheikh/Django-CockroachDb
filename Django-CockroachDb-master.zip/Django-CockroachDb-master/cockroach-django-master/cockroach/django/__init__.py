from .functions import register_functions

register_functions()
